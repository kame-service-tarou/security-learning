const express = require('express');

const FLAG = process.env.FLAG ?? "Alpaca{REDACTED}";

const app = express();

const html = `
<!DOCTYPE html>
<html>
  <body>
    <h1>Sorry, this page is only available for Switch users</h1>
  </body>
</html>
`;

const htmlForSwitch = `
<!DOCTYPE html>
<html>
  <body>
    <h1>Welcome, Switch user! Here is your flag: ${FLAG}</h1>
  </body>
</html>
`;

app.get("/", async (req, res) => {
  const userAgent = req.headers['user-agent'] || '';
  if (userAgent.includes("Switch")) {
    res.send(htmlForSwitch);
  } else {
    res.send(html);
  }
});

app.listen(3000, () => {
  console.log('Server listening on port 3000');
});